# Dicoding Fundamental Android Submission 2

#### Screenshots Submission 2
<img src="https://github.com/MayorBee404/Fundamental-Android-Submission2/blob/master/screenshot/Screenshot_20220317_165321.png"
     alt="Submission1 2"
     style="float: left; margin-right: 10px;"
     width="200" /> 
<img src="https://github.com/MayorBee404/Fundamental-Android-Submission2/blob/master/screenshot/Screenshot_20220318_175129.png"
     alt="Submission1 2"
     style="float: left; margin-right: 10px;"
     width="200" />
<img src="https://github.com/MayorBee404/Fundamental-Android-Submission2/blob/master/screenshot/Screenshot_20220318_173046.png"
     alt="Submission1 2"
     style="float: left; margin-right: 10px;"
     width="200" />

#### Submission 1 Checklists
- [x] Mempertahankan fitur pada Submission 1. (Terpenuhi)</strong>.
- [x] Pencarian User menggunakan data dari API berjalan dengan baik. (Terpenuhi)</strong>.
- [x] Menggunakan TabLayout sebagai navigasi antara halaman List Follower dan List Following. (Terpenuhi) </strong>.
- [x] Terdapat indikator loading saat aplikasi memuat data di semua halaman. (Terpenuhi).</strong>
- [x] Aplikasi tidak force closed. (Terpenuhi) </strong>

#### Review Cheklists
:star::star::star::star::star:
