# Dicoding Fundamental Android Submission 1



Submission 1 Checklists
- [x] Menampilkan data pada halaman aplikasi dengan minimal jumlah 10 item. (Terpenuhi) <strong>10 item</strong>.
- [x] Menggunakan RecyclerView. (Terpenuhi)</strong>.
- [x] Menampilkan avatar dan informasi user pada halaman Detail User. (Terpenuhi) </strong>.
- [x] Menggunakan Parcelable sebagai interface dari obyek data yang akan dikirimkan antar Activity. (Terpenuhi).</strong>
- [x] Aplikasi tidak force closed. (Terpenuhi)</strong>

